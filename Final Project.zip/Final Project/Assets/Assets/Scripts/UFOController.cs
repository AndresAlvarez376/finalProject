﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UFOController : MonoBehaviour {
    public GameObject laserPrefab;
    public Transform laserSpawn;
    int count = 0;
    GameObject player;
    public float currentHealth;
    public float velocidad;
    float velInicial;

    // Use this for initialization
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        velInicial = velocidad;
    }

    void Update()
    {
        count = count + 1;

        if (count > 90)
        {
            count = 0;
            var laser = (GameObject)Instantiate(
                laserPrefab,
                new Vector2(this.gameObject.transform.position.x+1, this.gameObject.transform.position.y-2),
                laserSpawn.rotation);
            var heading = player.transform.position - laser.transform.position;
            var distance = heading.magnitude;
            var direction = heading / distance;
            laser.GetComponent<Rigidbody2D>().AddForce(new Vector2(heading.x * 40, heading.y * 40));

            Destroy(laser, 2.0f);
        }
    }

    void FixedUpdate()
    {/*
        if (this.gameObject.transform.position.y > 3.3f)
        {
            velocidad = velInicial;
            velocidad = velocidad * -1;
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, velocidad));
        }
        if (this.gameObject.transform.position.y < -3f)
        {
            velocidad = velInicial;
            velocidad = velocidad * -1;
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, velocidad));
        }*/
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "bullet")
        {
            Destroy(collision.gameObject);
            Damage(20f);
        }
    }
    public void Damage(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            velocidad = 0;
            this.gameObject.GetComponent<AudioSource>().Play();
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 100f));
            if (this.gameObject.transform.position.y < -10)
            {
                Destroy(this.gameObject);
            }            
        }
    }
}
