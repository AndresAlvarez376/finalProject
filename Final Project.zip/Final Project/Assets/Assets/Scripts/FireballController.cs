﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireballController : MonoBehaviour {

    public Vector3 posicion;
    public float fuerza;
    public float cambio;
	// Use this for initialization
	void Start () {
        posicion = this.gameObject.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, fuerza));
        Vector3 nposicion = this.gameObject.transform.position;
        if (nposicion.y > posicion.y + cambio)
        {
            this.gameObject.transform.position = posicion;
            this.gameObject.GetComponent<AudioSource>().Play();
        }
	}

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            this.gameObject.transform.position = posicion;
            this.gameObject.GetComponent<AudioSource>().Play();
        }
        if (collision.gameObject.tag == "ground")
        {
            this.gameObject.transform.position = posicion;
            this.gameObject.GetComponent<AudioSource>().Play();
        }
    }
}
