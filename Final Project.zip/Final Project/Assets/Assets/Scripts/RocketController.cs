﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketController : MonoBehaviour
{

    private Transform thisTransform = null;
    public float rotSpeed = 90f;

    public Transform target = null;

    // a decrease in the amplitud of an oscillation as a result
    // of energy being drained from the system to overcome
    // frictional or other resistive forces
    public float damping = 55f;

    void Awake()
    {
        thisTransform = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        //rotateTowards();
        rotateTowardsWithDamp();
    }

    void rotateTowards()
    {
        //Get look to rotation
        Quaternion desRot = Quaternion.LookRotation(target.position - transform.position, Vector3.up);

        //Update rotation
        transform.rotation = Quaternion.RotateTowards(transform.rotation, desRot, rotSpeed * Time.deltaTime);
    }

    void rotateTowardsWithDamp()
    {
        //Get look to rotation
        Quaternion desRot = Quaternion.LookRotation(target.position - transform.position, Vector3.up);

        //Calc smooth rotate
        Quaternion smoothRot = Quaternion.Slerp(transform.rotation, desRot, 1f - (Time.deltaTime * damping));

        //Update Rotation
        transform.rotation = smoothRot;
    }
}
