﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        GetComponent<AudioSource>().Play();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 characterPosition = GameObject.Find("Player").transform.position;
        this.transform.position = new Vector3(characterPosition.x + 10,
            this.transform.position.y, characterPosition.z - 10);
    }
}