﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class BradleyController : MonoBehaviour {

    public GameObject rocketPrefab;
    public Transform rocketSpawn;
    int count = 0;
    GameObject player;
    public float currentHealth;

	// Use this for initialization
	void Start () {
        player = GameObject.FindGameObjectWithTag("Player");
	}
	
	void Update () {
        count = count + 1;
        
        if (count > 130)
        {
            count = 0;
            var rocket=(GameObject) Instantiate(
                rocketPrefab,
                new Vector2(this.gameObject.transform.position.x, this.gameObject.transform.position.y),
                rocketSpawn.rotation);
            var heading = player.transform.position - rocket.transform.position;
            var distance = heading.magnitude;
            var direction = heading /distance;
            rocket.GetComponent<Rigidbody2D>().AddForce(new Vector2(heading.x*40,heading.y*40));
        }
	}

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "bullet")
        {
            Destroy(collision.gameObject);
            Damage(20f);
        }
    }
    public void Damage(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            this.gameObject.GetComponent<Animator>().SetBool("isDeath", true);
            if(this.gameObject.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("Bradley Death")){
                this.gameObject.GetComponent<AudioSource>().Stop();
                Destroy(this.gameObject);
            }
        }
    }
}
