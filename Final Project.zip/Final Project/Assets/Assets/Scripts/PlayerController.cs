﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    bool jump = false;
    bool grounded = false;
    bool alive = true;
    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    // Use this for initialization
    void Start() {
        Invoke("Explode", fuseTime);
    }

    public bool destroyOnDeath;

    public float currentHealth;

    public Scrollbar healthBar;

    public void TakeDamage(float amount)
    {
        currentHealth -= amount;
        healthBar.size = currentHealth / 100f;
        Debug.Log("Actual Health: " + currentHealth);

        if (currentHealth <= 0)
        {
            Debug.Log("You are death!");
            if (destroyOnDeath)
            {
                Destroy(gameObject);
                SceneManager.LoadScene("menu");
            }
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            grounded = true;
        }
        if (collision.gameObject.tag == "rocket")
        {
            TakeDamage(15f);
        }
        if(collision.gameObject.tag == "fireball")
        {
            TakeDamage(20f);
        }
        if (collision.gameObject.tag == "life")
        {
            TakeDamage(-50f);
            Destroy(collision.gameObject);
        }
        if (collision.gameObject.tag == "laser")
        {
            TakeDamage(10f);
            Destroy(collision.gameObject);
        }
    }

    // Update is called once per frame
    void Update() {
        
    }

    public float fuseTime;
    void OnTriggerEnter2D(Collider2D collision)
    {
        Destroy(collision.gameObject);
        Debug.Log(collision.tag);
        switch (collision.tag)
        {
            case "rocket":
                TakeDamage(15f);
                Explode(collision);
                break;
            case "life":
                TakeDamage(-50f);
                break;
            case "fireball":
                Explode(collision);
                break;
            case "laser":
                TakeDamage(10f);
                break;
        }
    }

    public ParticleSystem explosion;
    void Explode(Collider2D collision)
    {
        ParticleSystem exp = Instantiate(explosion, collision.transform.position, Quaternion.identity) as ParticleSystem;

        exp.Play();
        Destroy(exp, explosion.main.duration);
    }

    void FixedUpdate()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            var bullet = (GameObject)Instantiate(
            bulletPrefab,
            new Vector2(this.gameObject.transform.position.x + 1, this.gameObject.transform.position.y),
            bulletSpawn.rotation);

            //Add velocity to the bullet
            bullet.GetComponent<Rigidbody2D>().velocity = new Vector2(15f, 0f);


            //Destroy the bullet after 2 seconds
            Destroy(bullet, 2.0f);

            this.gameObject.GetComponent<Animator>().SetBool("moveRight", false);
            this.gameObject.GetComponent<Animator>().SetBool("moveLeft", false);


            this.gameObject.GetComponent<Animator>().SetBool("standBy", false);
            this.gameObject.GetComponent<Animator>().SetBool("shootFront", true);
        }
        if (Input.GetKeyDown(KeyCode.Space) && grounded == true)
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, 15);
            grounded = false;
        }
        
        if (Input.GetKey(KeyCode.RightArrow))
        {
     
            this.gameObject.GetComponent<Animator>().SetBool("standBy", false);
            this.gameObject.GetComponent<Animator>().SetBool("moveLeft", false);
            this.gameObject.GetComponent<Animator>().SetBool("moveRight", true);
     
            this.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(15f, GetComponent<Rigidbody2D>().velocity.y);
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
     
            this.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(-15f, GetComponent<Rigidbody2D>().velocity.y);
            this.gameObject.GetComponent<Animator>().SetBool("standBy", false);
            this.gameObject.GetComponent<Animator>().SetBool("moveRight", false);
            this.gameObject.GetComponent<Animator>().SetBool("moveLeft", true);
     
        }

        if (Input.GetKeyUp(KeyCode.RightArrow))
        {
     
            this.gameObject.GetComponent<Animator>().SetBool("moveRight", false);
            this.gameObject.GetComponent<Animator>().SetBool("standBy", true);
            
        }
        if (Input.GetKeyUp(KeyCode.LeftArrow))
        {
            
            this.gameObject.GetComponent<Animator>().SetBool("moveLeft", false);
            this.gameObject.GetComponent<Animator>().SetBool("standBy", true);
            
        }
        
        if (Input.GetKeyUp(KeyCode.Z))
        {
            this.gameObject.GetComponent<Animator>().SetBool("shootFront", false);
            this.gameObject.GetComponent<Animator>().SetBool("standBy", true);
        }
        
        if (this.gameObject.transform.position.y < -30f)
        {
            alive = false;
        }
        if (alive == false)
        {
            Destroy(this.gameObject);
            Debug.Log("Death!");
            SceneManager.LoadScene("menu");
        }
    }
}
    
