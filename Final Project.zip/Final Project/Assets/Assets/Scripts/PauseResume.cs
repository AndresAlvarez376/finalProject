﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseResume : MonoBehaviour {

    public Sprite pauseSprite;
    public Sprite resumeSprite;
    bool paused = false;
    
    public void PauseOrResume()
    {
        if (paused)
        {
            Time.timeScale = 1;
            this.GetComponent<Image>().sprite = pauseSprite;
            paused = false;
        }
        else
        {
            Time.timeScale = 0;
            this.GetComponent<Image>().sprite = resumeSprite;
            paused = true;
        }
    }
}
