﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {

    //public const int maxHealth = 100;

    public bool destroyOnDeath;

    public float currentHealth;

    public Scrollbar healthBar;

    public void TakeDamage(float amount)
    {
        currentHealth -= amount;
        healthBar.size = currentHealth / 100f;
        Debug.Log("Actual Health: " + currentHealth);

        if (currentHealth <= 0)
        {
            Debug.Log("You are death!");
            if (destroyOnDeath)
            {
                Destroy(gameObject);
            }
        }
    }
}
